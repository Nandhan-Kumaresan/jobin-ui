import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';


@Injectable({
  providedIn: 'root'
})
export class ServiceShared {
  private REST_API_SERVER = 'your api link'; //(ex): http://localhost:8080
  constructor(private http: HttpClient) {

  }

  getData() {
    return this.http.get(this.REST_API_SERVER);
  }
}