import {  Injectable} from '@angular/core';

@Injectable()
export class ServiceData{
  _showdetails = '';
  set showdetails(value: string ){
    this._showdetails = value;
      }
  get showdetails(): string{
    return this._showdetails;
  }

  constructor(){

  }

}
