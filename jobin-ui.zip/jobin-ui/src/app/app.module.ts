import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { RouterModule } from '@angular/router';
import { HttpClientModule } from '@angular/common/http';
import { AppComponent } from './app.component';
import { LoginPageComponent } from './UI/login-page/login-page.component';
import { RegisterPageComponent } from './UI/register-page/register-page.component';
import { HomePageComponent } from './UI/home-page/home-page.component';
import { ContactPageComponent } from './UI/contact-page/contact-page.component';
import { DashboardPageComponent } from './UI/dashboard-page/dashboard-page.component';
import { ServiceShared } from './Shared/ServiceShared';
import { ServiceData } from './Shared/ServiceData';

@NgModule({
  declarations: [
    AppComponent,
    LoginPageComponent,
    RegisterPageComponent,
    HomePageComponent,
    ContactPageComponent,
    DashboardPageComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    AppRoutingModule,
    RouterModule,
    HttpClientModule
  ],
  providers: [ServiceShared, ServiceData],
  bootstrap: [AppComponent]
})
export class AppModule { }
