import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ServiceData } from '../../Shared/ServiceData';
@Component({
  selector: 'app-login-page',
  templateUrl: './login-page.component.html',
  styleUrls: ['./login-page.component.css']
})
export class LoginPageComponent implements OnInit {

  constructor(
    public serviceData: ServiceData,
    private router: Router) { }

    user: string;
    nouser: string;
  ngOnInit() {
  }

  onSignIn() {
    if (this.serviceData.showdetails == this.user) {
      this.router.navigate(['/dashboard-page']);
      this.nouser = '';
    }
    else {
      this.nouser = 'Your name is not regitered. Please register to proceed';
    }
  }

onRegister() {
  this.router.navigate(['/register-page']);
}
onContact() {
  this.router.navigate(['/contact-page']);
}

}
