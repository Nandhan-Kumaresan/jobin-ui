import { Component, OnInit } from '@angular/core';
import { ServiceData } from '../../Shared/ServiceData';
import { Router } from '@angular/router';

@Component({
  selector: 'app-dashboard-page',
  templateUrl: './dashboard-page.component.html',
  styleUrls: ['./dashboard-page.component.css']
})
export class DashboardPageComponent implements OnInit {

  constructor(public serviceData: ServiceData,
              private router: Router) { }

  name: string;
  ngOnInit() {
    if (this.serviceData.showdetails != '') {
      this.name = this.serviceData.showdetails;
    }
    else {
      this.router.navigate(['/login-page']);
    }
  }

  onLogout() {
    this.serviceData.showdetails = '';
    this.router.navigate(['/login-page']);
  }
}
