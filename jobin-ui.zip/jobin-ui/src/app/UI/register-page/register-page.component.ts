import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ServiceData } from '../../Shared/ServiceData';

@Component({
  selector: 'app-register-page',
  templateUrl: './register-page.component.html',
  styleUrls: ['./register-page.component.css']
})
export class RegisterPageComponent implements OnInit {

  constructor(public serviceData: ServiceData,
    private router: Router) { }

    name: string;
  ngOnInit() {
  }
  onSubmit() {
    this.serviceData.showdetails = this.name;
    this.router.navigate(['/login-page']);
    this.onLogin();
  }
onLogin() {
  this.router.navigate(['/login-page']);
}
onHome() {
  this.router.navigate(['/home-page']);
}
}
