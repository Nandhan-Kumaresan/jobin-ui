import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginPageComponent } from './UI/login-page/login-page.component';
import { RegisterPageComponent } from './UI/register-page/register-page.component';
import { HomePageComponent } from './UI/home-page/home-page.component';
import { ContactPageComponent } from './UI/contact-page/contact-page.component';
import { DashboardPageComponent } from './UI/dashboard-page/dashboard-page.component';



const routes: Routes = [
  { path: '', redirectTo: 'home-page', pathMatch: 'full' },
    { path: 'register-page', component: RegisterPageComponent },
    { path: 'login-page', component: LoginPageComponent },
    {path: 'home-page', component: HomePageComponent},
    { path: 'contact-page', component: ContactPageComponent },
    { path: 'dashboard-page', component: DashboardPageComponent },
    { path: '**', component: LoginPageComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes, { enableTracing: true })],
  exports: [RouterModule]
})
export class AppRoutingModule { }
